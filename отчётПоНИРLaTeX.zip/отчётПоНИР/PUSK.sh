#!/bin/bash
make dissertation-formated
